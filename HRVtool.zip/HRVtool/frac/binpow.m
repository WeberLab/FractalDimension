function kitevo=binpow(be)
qi=0;
while (2^qi)<=be
   qi=qi+1;
end
kitevo=qi-1;
